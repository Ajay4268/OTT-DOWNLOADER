"""
JioCinema — supports up to 4K, Widevine L3, no strict DRM enforcement on some titles.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from utils.downloader import download
from utils.cookies import get_cookie_path

PLATFORM = "jiocinema"
BASE_URL  = "https://www.jiocinema.com"


def rip(url: str, quality: str = "4K", content_type: str = "movies", **kwargs):
    """Rip a JioCinema title."""
    cookie_file = get_cookie_path(PLATFORM)
    return download(
        url=url,
        platform=PLATFORM,
        content_type=content_type,
        quality=quality,
        cookie_file=cookie_file,
        **kwargs,
    )


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", required=True)
    parser.add_argument("--quality", default="4K")
    parser.add_argument("--type", default="movies")
    args = parser.parse_args()
    rip(args.url, quality=args.quality, content_type=args.type)
